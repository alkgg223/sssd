package com.zebrafinch.mod;

import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.animal.Fox;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Bird dropping thrown by adult finches. Flies almost straight, like an arrow. Only hits foxes and raccoons. */
public class FinchDropping extends ThrowableItemProjectile {

    public FinchDropping(EntityType<? extends FinchDropping> type, Level level) {
        super(type, level);
    }

    public FinchDropping(Level level, LivingEntity shooter) {
        super(ModEntities.DROPPING.get(), shooter, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.DROPPING.get();
    }

    @Override
    protected double getDefaultGravity() {
        return 0.01D;
    }

    @Override
    protected boolean canHitEntity(Entity entity) {
        return (entity instanceof Fox || entity instanceof Raccoon) && super.canHitEntity(entity);
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (level().isClientSide) {
            return;
        }
        if (result.getEntity() instanceof Raccoon raccoon) {
            raccoon.hurt(damageSources().thrown(this, getOwner()), 1.0F);
            Vec3 origin = getOwner() != null ? getOwner().position() : position();
            raccoon.scare(300, true, origin);
            return;
        }
        if (!(result.getEntity() instanceof Fox fox)) {
            return;
        }
        fox.hurt(damageSources().thrown(this, getOwner()), 0.5F);
        fox.getPersistentData().putLong(FinchNestBlockEntity.SCARED_KEY, level().getGameTime() + 600L);
        fox.setTarget(null);
        Vec3 from = getOwner() != null ? getOwner().position() : position();
        Vec3 away = DefaultRandomPos.getPosAway(fox, 24, 10, from);
        if (away != null) {
            fox.getNavigation().moveTo(away.x, away.y, away.z, 1.6D);
        }
        fox.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 100, 1));
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide) {
            this.discard();
        }
    }
}

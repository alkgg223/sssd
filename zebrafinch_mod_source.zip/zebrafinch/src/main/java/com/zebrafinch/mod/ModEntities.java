package com.zebrafinch.mod;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, ZebraFinchMod.MODID);

    // Half of the vanilla parrot hitbox (0.25 x 0.45)
    public static final DeferredHolder<EntityType<?>, EntityType<ZebraFinch>> ZEBRA_FINCH =
            ENTITIES.register("zebra_finch", () -> EntityType.Builder.of(ZebraFinch::new, MobCategory.CREATURE)
                    .sized(0.25F, 0.45F)
                    .clientTrackingRange(8)
                    .build("zebra_finch"));

    public static final DeferredHolder<EntityType<?>, EntityType<Raccoon>> RACCOON =
            ENTITIES.register("raccoon", () -> EntityType.Builder.of(Raccoon::new, MobCategory.CREATURE)
                    .sized(0.6F, 0.7F)
                    .clientTrackingRange(8)
                    .build("raccoon"));

    public static final DeferredHolder<EntityType<?>, EntityType<FinchDropping>> DROPPING =
            ENTITIES.register("finch_dropping", () -> EntityType.Builder.<FinchDropping>of(FinchDropping::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build("finch_dropping"));
}

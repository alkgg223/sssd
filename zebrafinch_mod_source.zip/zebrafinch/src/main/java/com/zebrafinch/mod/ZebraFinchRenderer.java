package com.zebrafinch.mod;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class ZebraFinchRenderer extends MobRenderer<ZebraFinch, ZebraFinchModel> {
    private static final ResourceLocation MALE = tex("zebra_finch_male");
    private static final ResourceLocation FEMALE = tex("zebra_finch_female");
    private static final ResourceLocation MALE_WHITE = tex("zebra_finch_male_white");
    private static final ResourceLocation FEMALE_WHITE = tex("zebra_finch_female_white");

    private static ResourceLocation tex(String name) {
        return ResourceLocation.fromNamespaceAndPath(ZebraFinchMod.MODID, "textures/entity/" + name + ".png");
    }

    public ZebraFinchRenderer(EntityRendererProvider.Context context) {
        super(context, new ZebraFinchModel(context.bakeLayer(ZebraFinchModel.LAYER)), 0.1F);
    }

    @Override
    public ResourceLocation getTextureLocation(ZebraFinch finch) {
        if (finch.isWhite()) {
            return finch.isFemale() ? FEMALE_WHITE : MALE_WHITE;
        }
        return finch.isFemale() ? FEMALE : MALE;
    }

    @Override
    protected void scale(ZebraFinch finch, PoseStack poseStack, float partialTick) {
        float s = finch.isBaby() ? 0.15F : 0.25F;   // model is drawn at 2x, so 0.25 = half of the old size
        poseStack.scale(s, s, s);
    }

    @Override
    protected float getBob(ZebraFinch finch, float partialTick) {
        float f = Mth.lerp(partialTick, finch.oFlap, finch.flap);
        float g = Mth.lerp(partialTick, finch.oFlapSpeed, finch.flapSpeed);
        return (Mth.sin(f) + 1.0F) * g;
    }
}

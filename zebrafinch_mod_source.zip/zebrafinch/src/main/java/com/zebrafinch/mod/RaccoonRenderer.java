package com.zebrafinch.mod;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class RaccoonRenderer extends MobRenderer<Raccoon, RaccoonModel> {
    private static final ResourceLocation TEXTURE =
            ResourceLocation.fromNamespaceAndPath(ZebraFinchMod.MODID, "textures/entity/raccoon.png");

    public RaccoonRenderer(EntityRendererProvider.Context context) {
        super(context, new RaccoonModel(context.bakeLayer(RaccoonModel.LAYER)), 0.45F);
    }

    @Override
    public ResourceLocation getTextureLocation(Raccoon raccoon) {
        return TEXTURE;
    }

    @Override
    protected void scale(Raccoon raccoon, PoseStack poseStack, float partialTick) {
        float s = raccoon.isBaby() ? 0.3F : 0.5F;   // model is drawn at 2x resolution
        poseStack.scale(s, s, s);
    }
}

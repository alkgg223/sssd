package com.zebrafinch.mod;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.WallClimberNavigation;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Raccoon: sneaks towards finch nests it smells within 20 blocks, steals an egg, carries it in its mouth,
 * runs to the nearest water (up to 64 blocks) and "washes" it by dropping it on the bottom, where it spoils.
 */
public class Raccoon extends Animal {
    private static final EntityDataAccessor<Boolean> DATA_STALKING =
            SynchedEntityData.defineId(Raccoon.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_EGG =
            SynchedEntityData.defineId(Raccoon.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_WASHING =
            SynchedEntityData.defineId(Raccoon.class, EntityDataSerializers.BOOLEAN);

    /** client + server, smoothed 0..1 value used by the model for the sneak pose */
    public float sneakAmount;
    public float oSneakAmount;

    private int scaredTicks;
    private boolean hunted;
    private int stealCooldown = 600;
    private boolean climbHint;
    @Nullable private Vec3 scareFrom;

    public Raccoon(EntityType<? extends Raccoon> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Animal.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 16.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 32.0D);
    }

    public static boolean checkSpawnRules(EntityType<Raccoon> type, LevelAccessor level, MobSpawnType spawnType,
                                          BlockPos pos, RandomSource random) {
        return Animal.checkAnimalSpawnRules(type, level, spawnType, pos, random);
    }

    // ---------------------------------------------------------------- data
    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_STALKING, false);
        builder.define(DATA_EGG, false);
        builder.define(DATA_WASHING, false);
    }

    public boolean isStalking() { return this.entityData.get(DATA_STALKING); }
    public void setStalking(boolean value) { this.entityData.set(DATA_STALKING, value); }
    public boolean isCarryingEgg() { return this.entityData.get(DATA_EGG); }
    public void setCarryingEgg(boolean value) { this.entityData.set(DATA_EGG, value); }
    public boolean isWashing() { return this.entityData.get(DATA_WASHING); }
    public void setWashing(boolean value) { this.entityData.set(DATA_WASHING, value); }

    public float getSneakAmount() { return this.sneakAmount; }

    public int getStealCooldown() { return this.stealCooldown; }
    public void setStealCooldown(int ticks) { this.stealCooldown = ticks; }
    public void setClimbHint(boolean value) { this.climbHint = value; }
    public boolean isScared() { return this.scaredTicks > 0; }
    @Nullable public Vec3 getScareFrom() { return this.scareFrom; }

    /** Finches spotted the raccoon (or hit it): drop everything and run. */
    public void scare(int ticks, boolean huntedByFinches, @Nullable Vec3 from) {
        this.scaredTicks = Math.max(this.scaredTicks, ticks);
        this.hunted = this.hunted || huntedByFinches;
        this.scareFrom = from;
        this.setStalking(false);
        this.setWashing(false);
        this.climbHint = false;
        this.getNavigation().stop();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("HasEgg", isCarryingEgg());
        tag.putInt("StealCooldown", stealCooldown);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setCarryingEgg(tag.getBoolean("HasEgg"));
        stealCooldown = tag.getInt("StealCooldown");
    }

    // ---------------------------------------------------------------- animals plumbing
    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob partner) {
        return ModEntities.RACCOON.get().create(level);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return false;
    }

    // ---------------------------------------------------------------- ai
    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PanicGoal(this, 1.4D));
        this.goalSelector.addGoal(1, new RaccoonGoals.ScaredRunGoal(this));
        this.goalSelector.addGoal(2, new RaccoonGoals.StealEggGoal(this));
        this.goalSelector.addGoal(3, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
    }

    /** Wall-climber navigation: lets the raccoon go up tree trunks towards a nest in the leaves. */
    @Override
    protected PathNavigation createNavigation(Level level) {
        return new WallClimberNavigation(this, level);
    }

    @Override
    public boolean onClimbable() {
        return this.horizontalCollision && this.climbHint;
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return super.causeFallDamage(distance, multiplier * 0.25F, source);
    }

    @Override
    public void aiStep() {
        super.aiStep();

        this.oSneakAmount = this.sneakAmount;
        float target = this.isStalking() ? 1.0F : 0.0F;
        this.sneakAmount += Mth.clamp(target - this.sneakAmount, -0.15F, 0.15F);

        if (!this.level().isClientSide) {
            if (this.stealCooldown > 0) {
                this.stealCooldown--;
            }
            if (this.scaredTicks > 0) {
                this.scaredTicks--;
                if (this.hunted && this.scaredTicks > 30 && this.tickCount % 20 == 0) {
                    RaccoonGoals.alertFinches(this);
                }
                if (this.scaredTicks == 0) {
                    this.hunted = false;
                    this.scareFrom = null;
                }
            }
        }
    }

    // ---------------------------------------------------------------- sounds
    @Override
    public int getAmbientSoundInterval() {
        return 220;
    }

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return ModSounds.RACCOON_CHITTER.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.RACCOON_CHITTER.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModSounds.RACCOON_CHITTER.get();
    }

    @Override
    protected float getSoundVolume() {
        return 0.8F;
    }
}
